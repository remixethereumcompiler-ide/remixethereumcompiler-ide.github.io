# Research Project: Improving the Usability of Remix

Researchers from the University of Münster (Germany) and Innsbruck (Austria) are conducting a research project on improving the usability of Remix. Part of the project is to develop a questionnaire and to pretest it in a pilot study. We kindly ask you to **take part in the pilot study** by visiting http://informatik-remix.uibk.ac.at. Your participation is highly appreciated and will contribute to research on Smart Contract development.

<sub>If you have any questions, please contact the researcher in charge:
Dominique Machuletz
Department of Information Systems
University of Münster, Germany
d.machuletz@uni-muenster.de </sub>
