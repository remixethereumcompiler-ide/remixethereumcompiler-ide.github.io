var csjs = require('csjs-inject')

var css = csjs`
  .prompt_text {
    width: 100%;
  }
`

module.exports = css
