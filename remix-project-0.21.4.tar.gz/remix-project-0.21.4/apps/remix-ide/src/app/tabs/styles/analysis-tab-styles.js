var csjs = require('csjs-inject')

const css = csjs`
`

module.exports = css
